!function(){
    "use strict";
   var obj=[{'name':'jeswin'}];
    angular.module("myApp",[])
    .controller("lol",conf)
    .factory('f',func)
    .directive('poop',function(){
        return{
            scope:{
                num1:'@',
                num2:'='
            },
            template: '<h1>{{num1*num2}}</h1>',
        }
    })
    
    function func()
    {
        var factory={}
        factory.add=function(name){
            var item={'name':name};
            obj.push(item);
        
        }
        factory.rem=function(idx){
            obj.splice(idx,1);
        }
        return factory;
    }
    
    function conf($scope,f)
    {
        $scope.obj=obj;
        $scope.an=function(){
            $scope.result=f.add($scope.name);

        }
        $scope.r=function(ind){
            $scope.result=f.rem(ind);
        }
    };
}();