var calculator = require('./arithmetic.js');
var x = 10, y = 6;
console.log("Addition of 10 and 6 is " + calculator.add(x, y) + ".");
console.log("Subtraction of 10 and 6 is " + calculator.sub(x, y) + ".");
console.log("The square of 10 is " + calculator.square(x) + ".");
console.log("The square of 6 is " + calculator.square(y) + ".");