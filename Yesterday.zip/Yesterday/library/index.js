	const express =require('express');
const sql =require('mysql2');
const bp = require('body-parser');

const app =express();

app.use(bp.json());
app.use(bp.urlencoded({ extended: false }));
app.use(express.static('script'));

const db = sql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'lib',
	port:'3306'
});

db.connect((err)=>{
	if(err){
		console.log('Db connection error : ',err);
	}
	console.log('DB connected')
});

app.get('/library',(req,res)=>{
	res.sendFile(`${__dirname}/Library.html`);
})

app.get('/getBooks',(req,res)=>{
	let qr = `SELECT * from books`;
	db.query(qr,(err,result)=>{
		if(err){
			console.log(err);
		}
		console.log(result);
		var books = result;
		res.send(books);
	})
})

app.post('/setBooks',(req,res)=>{

	var name = req.body.name;
	let qr = `INSERT into books(name) values('${name}')`;
	db.query(qr,(err,result)=>{
		if(err){
			console.log(err);
		}
	})
	res.redirect('/library');
})

app.listen(3100,()=>{
	console.log('Server listening on 3100 !!!!!!!!!!!');

})



