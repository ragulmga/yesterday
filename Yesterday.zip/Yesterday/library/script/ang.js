

var app = angular.module('myapp',[]);
var book = [{'name':'Dixon','price':100}];

app.service('service',function(){
	var service = this;
	this.addB = function(name1,price1){
		book.push({'name':name,'price':price});
	}
	this.remB = function(ind){
		book.splice(ind,1);
	}
})

app.controller('mycontroller',function($scope,$http,service){
	$http.get('/getBooks').then(function(data){
		$scope.books = data.data;
	});

	$scope.book = book;	

	$scope.add = function(){
		service.addB($scope.newItem,$scope.newPrice);
	}
	$scope.rem = function(ind){
		$scope.remB(ind);
	}

})

