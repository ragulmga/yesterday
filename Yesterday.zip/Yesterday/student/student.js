class student
{
getDetails(name, course1, course2, mark1, mark2)
{
console.log();
console.log('Name: ' +name);
console.log('Course 1: ' + course1);
console.log('Mark: ' + mark1);
console.log('Course 2: '+ course2);
console.log('Mark:' + mark2);
}
calGrade (course, mark)
{
console.log('Course: ' + course);
if(mark>90)
    return 'S';
else if(mark>80)
    return 'A';
else if(mark>70)
    return 'B';
else if(mark>60)
    return 'C';
else if(mark>50)
    return 'D';
else
    return 'U';
}
}
module.exports = student;