const student =  require('./student.js');
const obj1 = new student();
const obj2 = new student();
obj1.getDetails('Messi', 'Python', 'OS', 96, 88);
console.log(obj1.calGrade('Python', 96));
console.log(obj1.calGrade('OS',88));
obj2.getDetails('Ronaldo', 'Python', 'OS', 78, 69);
console.log('Grade : ' + obj1.calGrade('Python', 78));
console.log('Grade : '+ obj1.calGrade('OS',69));