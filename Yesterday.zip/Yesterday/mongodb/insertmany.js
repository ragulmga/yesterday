var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydatabase");
  var myobj = [
    { name: "Arun Kalyan", regno: "19IT011" , rollno: "62825" , age: "19" },
    { name: "Dixon", regno: "19IT025" , rollno: "62306" , age: "20" },
    { name: "Prasanth", regno: "19F031" , rollno: "62500" , age: "20" },
    { name: "Sharath", regno: "19D088" , rollno: "62365" , age: "20" },
  ];
  dbo.collection("Student").insertMany(myobj, function(err, res) {
    if (err) throw err;
    console.log("Number of documents inserted: " + res.insertedCount);
    db.close();
  });
});
