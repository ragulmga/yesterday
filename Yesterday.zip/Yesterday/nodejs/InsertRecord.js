var mysql = require('mysql');
var con = mysql.createConnection({
 host: "localhost",
 user: "root",
 password: "",
 database: "BooksDatabase"
});
con.connect(function(err) {
 if (err) throw err;
 console.log("Connected!");
 var sql = "INSERT INTO BooksTable (name, author, price) VALUES ('Around the World in 80 Days', 'Jules Verne' , 'Rs 699')";
 con.query(sql, function (err, result) {
 if (err) throw err;
 console.log("Record inserted successfully!");
 });

});